#ifndef SHARED_WHITEBOARD_SERVICE_COMMAND_NAME_HPP
#define SHARED_WHITEBOARD_SERVICE_COMMAND_NAME_HPP
#include <string>
namespace ServiceCommandName{
    const std::string ServiceUndoName = "ServiceUndo";
    const std::string ServiceRedoName = "ServiceRedo";
}
#endif //SHARED_WHITEBOARD_SERVICE_COMMAND_NAME_HPP
